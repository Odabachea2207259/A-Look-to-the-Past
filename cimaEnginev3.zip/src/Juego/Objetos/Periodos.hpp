#pragma once

namespace IVJ
{
    enum class Periodos{
        Paleozoico = 1,
        Mesozoico = 7,
        Cenozoico = 10
    };

    //CAMBIAR PARA REALIZAR EL EJEMPLO DE LA PELEA DE JEFES
    const int PALEOZOICO = 1;
    const int MESOZOICO = 2; //7
    const int CENOZOICO = 10;
}